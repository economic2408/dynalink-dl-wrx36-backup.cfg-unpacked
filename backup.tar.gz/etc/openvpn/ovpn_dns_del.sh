#!/bin/sh
mv /tmp/resolv.conf.auto.hold /tmp/resolv.conf.auto
mv /tmp/resolv.conf.hold /tmp/resolv.conf

